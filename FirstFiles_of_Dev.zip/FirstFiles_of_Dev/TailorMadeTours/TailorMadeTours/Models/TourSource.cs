﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TailorMadeTours.Models
{
    class TourSource
    {
        private static List<TourStop> _tourStops;
        static TourSource()
        {
            //stops for our food and fun parks
            _tourStops = new List<TourStop>();
            _tourStops.Add(new TourStop
            {
                StopNumber = 1,
                Name = "Tea at Paddington's Bakeries",
                Latitude = "41.875943",
                Longitude = "-87.849234",
                Phone = "555-8234",
                Description = "Start the morning with a jolt of tasty tea from this trendy shop. Don't miss the TeaCakes, guaranteed to energise you for the day ahead.",
                ImageUri = "/TailorMadeTours;component/RandomBakeryPhoto.png",
                Selected = true,
                EstimatedMinutes = 30
            });
            _tourStops.Add(new TourStop
            {
                StopNumber = 1,
                Name = "Zapa",
                Latitude = "41.875943",
                Longitude = "-87.849234",
                Phone = "555-8234",
                Description = "Start the morning with a jolt of tasty tea from this trendy shop. Don't miss the TeaCakes, guaranteed to energise you for the day ahead.",
                ImageUri = "/TailorMadeTours;component/RandomBakeryPhoto.png",
                Selected = false,
                EstimatedMinutes = 15
            });
            _tourStops.Add(new TourStop
            {
                StopNumber = 1,
                Name = "Padd's Bakeries",
                Latitude = "41.875943",
                Longitude = "-87.849234",
                Phone = "555-8234",
                Description = "Start the morning with a jolt of tasty tea from this trendy shop. Don't miss the TeaCakes, guaranteed to energise you for the day ahead.",
                ImageUri = "/TailorMadeTours;component/RandomBakeryPhoto.png",
                Selected = false,
                EstimatedMinutes = 180,
                BusyTimes = new List<BusyTime>() { new BusyTime { Hour = 9, Rank =10} }
            });
            _tourStops.Add(new TourStop
            {
                StopNumber = 1,
                Name = "Baker's",
                Latitude = "41.875943",
                Longitude = "-87.849234",
                Phone = "555-8234",
                Description = "Start the morning with a jolt of tasty tea from this trendy shop. Don't miss the TeaCakes, guaranteed to energise you for the day ahead.",
                ImageUri = "/TailorMadeTours;component/RandomBakeryPhoto.png"
            });
            //...Continue Adding...
        }
        
        public static List<TourStop> GetAllTourStops()
        {
            var result = _tourStops.ToList<TourStop>();
            return result;
        }
    }
}
