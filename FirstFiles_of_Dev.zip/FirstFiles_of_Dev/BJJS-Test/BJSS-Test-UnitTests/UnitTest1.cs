using BJJS_Test;
using NUnit.Framework;

namespace BJSS_Test_UnitTests
{
    public class Tests
    {
        [SetUp]
        public void Setup(){        }
        

        [Test]
        public void residential()
        {
            var person = new Person() { propertyPrice = 450000, additionalDwelling = false };
            Assert.AreEqual(18350, person.residential_LBTT());
            Assert.AreEqual(0, person.non_residential_LBTT());
        }
        [Test]
        public void non_residential()
        {
            var person2 = new Person() { propertyPrice = 253000, additionalDwelling = false, propertyType = "conveyance" };
            Assert.AreEqual(1150, person2.non_residential_LBTT());
        }
        //[Test]
        //public void SDLT_residential()
        //{
        //    Person person = new Person() { propertyPrice = 90000 };
        //    Assert.AreEqual(0, person.residential_SDLT());
        //}
    }
}