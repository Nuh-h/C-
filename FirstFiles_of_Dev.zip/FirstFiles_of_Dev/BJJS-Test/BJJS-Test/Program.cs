﻿using System;

namespace BJJS_Test
{
    class Program
    {
        public static void Main()
        {
            //person 1
            Person buyer = new Person();
            buyer.additionalDwelling = true;
            buyer.propertyPrice = 450000;
            Console.WriteLine(buyer.residential_LBTT());

            //person 2
            Person person = new Person();
            person.additionalDwelling = false;
            person.propertyPrice = 253000;
            person.propertyType = "conveyance";
            Console.WriteLine(person.residential_LBTT());
            Console.WriteLine(person.non_residential_LBTT());
        }
    }
    public class Person
    {
        /*public int properties;*/
        public bool additionalDwelling;
        public int propertyPrice;
        public string propertyType;

        public int residential_LBTT()
        {
            //Old LBTT (outside the period of 15-July-2020 to 31-March-2021) as detailed in .https://www.gov.scot/policies/taxes/land-and-buildings-transaction-tax/ 
            int priceCopy = propertyPrice;
            int taxDue = 0;

            int tier1 = (725000 - 325000) * 10 / 100; //charge for range 325000 to 725000 when price>725000
            int tier2 = (325000 - 250000) * 5 / 100; //when price>325000
            int tier3 = (250000 - 145000) * 2 / 100; //when price>145000

            if (priceCopy > 750000)
            {
                taxDue += (priceCopy - 750000) * 12 / 100 +tier1 + tier2 + tier3;
                //priceCopy = 750000;
            }
            else if(priceCopy > 325000 )//&& priceCopy <= 750000)
            {
                taxDue += (priceCopy - 325000) * 10 / 100 + tier2 + tier3;
                //priceCopy = 325000;
            }
            else if(priceCopy > 250000)// && priceCopy <= 325000)
            {
                taxDue += (priceCopy - 250000) * 5 / 100 + tier3;
                //priceCopy = 250000;
            }
            else if(priceCopy > 145000)// && priceCopy <= 250000)
            {
                taxDue += (priceCopy - 145000) * 2 / 100;
                //priceCopy = 145000;
            }
            return additionalDwelling ? propertyPrice*4/100 + taxDue : taxDue;
        }
        public int non_residential_LBTT()
        {
            //Old LBTT (2019/20) as detailed in .https://www.gov.scot/policies/taxes/land-and-buildings-transaction-tax/ 
            int priceCopy = propertyPrice;
            int taxDue = 0;
            switch (propertyType)
            {
                case "conveyance":
                    if (priceCopy > 250000)
                    {
                        taxDue += (priceCopy - 250000) * 5 / 100;
                        priceCopy = 250000;
                    }
                    if (priceCopy > 150000 && priceCopy <= 250000)
                    {
                        taxDue += (priceCopy - 150000) * 1 / 100;
                        //priceCopy = 150000;
                    }
                    break;
                case "lease":
                    if (priceCopy > 2000000)
                    {
                        taxDue += (priceCopy - 2000000) * 2 / 100;
                        priceCopy = 2000000;
                    }
                    if (priceCopy > 150000 && priceCopy <= 2000000)
                    {
                        taxDue += (priceCopy - 150000) * 1 / 100;
                       // priceCopy = 150000;
                    }
                    break;
                default: break;
            }
            return taxDue;
        }

        //rates from before JUL-2020 and from APR-2021 .https://www.gov.uk/stamp-duty-land-tax/residential-property-rates
        public int residential_SDLT()
        {
            int priceCopy = propertyPrice;
            int taxDue = 0;
            int tier1 = (1500000 - 925000) * 10 / 100;
            int tier2 = (925000 - 250000) * 5 / 100;
            int tier3 = (250000 - 125000) * 2 / 100;

            if (priceCopy > 1500000)
            {
                taxDue += (priceCopy - 1500000)*12/100 + tier1 + tier2 + tier3;
            }
            else if(priceCopy > 925000)
            {
                taxDue += (priceCopy - 925000) * 10 / 100 + tier2 + tier3;
            }
            else if(priceCopy > 250000)
            {
                taxDue += (priceCopy - 250000) * 5 / 100 + tier3;
            }
            else if(priceCopy > 125000)
            {
                taxDue += (priceCopy - 125000) * 2 / 100;
            }
            return taxDue;
        }
    }
}
