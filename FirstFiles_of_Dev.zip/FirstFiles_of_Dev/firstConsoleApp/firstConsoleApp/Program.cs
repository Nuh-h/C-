﻿using System;

namespace firstConsoleApp
{
    class Program
    {
        public static string title = "Welcome to C# Essentials";
        public static int whichPart;
        static void Main(string[] args)
        {
            whichPart = 2;
            var message = string.Format("Welcome to {0} Part {1}", title, whichPart);
            Console.WriteLine(message);
            Console.WriteLine("Press Enter to exit");
            Console.ReadLine();
        }
    }
}
