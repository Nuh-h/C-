﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace BankApp
{
    class Bank
    {
        static void Main(string[] args)
        {
            /*            SAccount[] CustomerAccounts = new SAccount[100]; ;
                        CustomerAccounts[0].Name = "Rob";
                        CustomerAccounts[0].State = AccountState.Active;
                        CustomerAccounts[0].Balance = 1000000;
                        CustomerAccounts[1].Name = "Jim";
                        CustomerAccounts[1].State = AccountState.Frozen;
                        CustomerAccounts[1].Balance = 0;
                        Console.WriteLine($"There are {CustomerAccounts.Length} customer account(s) at the Bank!");
                        Console.WriteLine("These are: ");
                        foreach(SAccount customer in CustomerAccounts)
                        {
                            if(!(customer.Name is null))
                            {
                                PrintAccount(customer);
                            }
                        }*/
            //IAccount[] accounts = new IAccount[100];
            //accounts[0] = new CustomerAccount();
            //accounts[0].PayInFunds(50);
            //Console.WriteLine("Balance: " + accounts[0].GetBalance());
            //accounts[1] = new BabyAccount();
            //accounts[1].PayInFunds(20);
            //Console.WriteLine("Balance: " + accounts[1].GetBalance());
            //if (accounts[0].WithdrawFunds(20))
            //{
            //    Console.WriteLine("Withdraw OK");
            //}
            //if (accounts[1].WithdrawFunds(20))
            //{
            //    Console.WriteLine("Withdraw OK");
            //}
            string path = @"https://raw.githubusercontent.com/openfootball/football.json/master/2020-21/en.1.clubs.json";
            var textFromFile = (new WebClient()).DownloadString(path);
            //String myStream = ReadAllText(textFromFile);
            EplTeams myTeams = JsonConvert.DeserializeObject<EplTeams>(textFromFile);
            foreach (var team in myTeams.clubs)
            {
                Console.WriteLine(team.name);
            }
        }
        public class EplTeams
        {
            public string name
            {
                get;
                set;
            }

            public IList<Club> clubs
            {
                get;
                set;
            }
        }

        public class Club
        {
            public string name
            {
                get;
                set;
            }

            public string code
            {
                get;
                set;
            }

            public string country
            {
                get;
                set;
            }
        }

        public enum AccountState
        {
            New,
            Active,
            Frozen,
            UnderAudit,
            Closed
        };

        public struct SAccount
        {
            public AccountState State;
            public string Name;
            public string Address;
            public int AccountNumber;
            public int Balance;
            public int Overdraft;
        };

        public static void PrintAccount(SAccount a)
        {
            Console.WriteLine("Name: " + a.Name);
            Console.WriteLine("Address: " + a.Address);
            Console.WriteLine("Balance: " + a.Balance);
        }
        public interface IAccount
        {
            void PayInFunds(decimal amount);
            bool WithdrawFunds(decimal amount);
            decimal GetBalance();
            string RudeLetterString();
        }
        public abstract class Account : IAccount
        {
            private decimal balance = 0;
            public abstract string RudeLetterString();
            public virtual bool WithdrawFunds(decimal amount)
            {
                if (balance < amount)
                {
                    return false;
                }
                balance -= amount;
                return true;
            }
            public decimal GetBalance()
            {
                return balance;
            }
            public void PayInFunds(decimal amount)
            {
                balance += amount;
            }
        }
        public class CustomerAccount : Account
        {
            public override string RudeLetterString()
            {
                return "You are overdrawn";
            }
        }
        public class BabyAccount : Account
        {
            public override bool WithdrawFunds(decimal amount)
            {
                if (amount > 10)
                {
                    return false;
                }
                return base.WithdrawFunds(amount);
            }
            public override string RudeLetterString()
            {
                return "Tell daddy you are overdrawn";
            }
        }
    }
}
